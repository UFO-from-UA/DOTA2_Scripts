'use strict';



    $( "#draggable" ).draggable(cl);
    $( "#droppable" ).droppable(()=>{cl;});
  


  function cl(argument) {
   console.dir("123123");
  }